﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame;

public class GameData
{
    public int Width { get; private set; }
    public int Height { get; private set; }
    public DropHeartUpdate DropHeartUpdate;
    public DropHeartDraw DropHeartDraw;
    public HeroDraw DrawHero;
    public BackGround BackGround;
    public int CountUpdateHeroHelths;
    public HeroUpdate HeroUpdate;
    public TearData TearData;
    public int SpeedTear = 300;
    public float RangeTear = 0.8f;
    public Random Random;
    public EnemyData EnemyData;
    public bool CanPickUpHeart;
    public bool PickUpHeart;
    public int LimitSpawnEnemy;

    
    public void Init()
    {
        Width = Game1.graphics.PreferredBackBufferWidth;
        Height = Game1.graphics.PreferredBackBufferHeight;
        TearsManager.Init();
        EnemyManager.Init();
        HeartManager.Init();
        TearData = new TearData();
        DropHeartDraw = new DropHeartDraw();
        DropHeartUpdate = new DropHeartUpdate(Width, Height, Globals.Content.Load<Texture2D>("halfDroppedHeart"), Globals.Content.Load<Texture2D>("droppedHeart"));
        HeroUpdate = new HeroUpdate(Width, Height);
        DrawHero = new HeroDraw();
        Random = new Random();
        EnemyData = new EnemyData();
        TearData = new();
        BackGround = new BackGround();
    }
}