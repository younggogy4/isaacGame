﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame;

public class TearsManager
{
    private static Texture2D texture;
    public static List<Tear> Tears { get; } = new();

    public static void Init()
    {
        texture = Globals.Content.Load<Texture2D>("tear");
    }

    public static void Add(TearData data)
    {
        Tears.Add(new Tear(texture, data));
    }
    
    public static void Shoot(TearData tearData, float rangeTear, int speedTear, HeroUpdate updateHero)
    {
        tearData.Range = rangeTear;
        tearData.Speed = speedTear;
        tearData.Position = new Vector2(updateHero.Position.X, updateHero.Position.Y);
        Add(tearData);
    }

    public static void Update()
    {
        foreach (var t in Tears)
        {
            t.Position += t.Direction * t.Speed * (float)Globals.Time.TotalSeconds;
            t.Range -= (float)Globals.Time.TotalSeconds;
        }

        Tears.RemoveAll(t => t.Range <= 0);
    }

    public static void Draw()
    {
        foreach (var t in Tears)
        {
            Globals.SpriteBatch.Draw(texture, new Vector2(t.Position.X, t.Position.Y+10), Color.White);
        }
    }
}