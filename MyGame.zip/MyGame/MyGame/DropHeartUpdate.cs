﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame;

public class DropHeartUpdate
{
    public static Vector2 Position;
    public readonly Texture2D textureHalfHeart;
    public readonly Texture2D textureHeart;
    public static int TextureWidth;
    public static int TextureHeight;
    private Random chance;
    public static bool ChanceDropHeart;
    public static int CountCheckChance;
    public static Rectangle Bounds { get; set; }
    public static bool canTakeHeart;
    public bool dropHeart;
    public bool dropHalfHeart;
    
    public DropHeartUpdate(int width, int height, Texture2D textureHalfHeart, Texture2D textureHeart)
    {
        chance = new Random();
        Position = new Vector2(width / 2, height / 2);
        this.textureHalfHeart = textureHalfHeart;
        this.textureHeart = textureHeart;
        TextureWidth = 50;
        TextureHeight = 40;
        Bounds = new Rectangle((int)Position.X, (int)Position.Y, TextureWidth,TextureHeight);
    }
    
    
    public static void Update(GameData gameData)
    {
        if (gameData.HeroUpdate.Healths <= 0) return;
        if (HeartManager.Hearts[^1].CountHeart == 2 || HeartManager.Hearts[^1].CountHeart==1)
            gameData.CanPickUpHeart = true;

        if (gameData.HeroUpdate.Bounds.Intersects(Bounds) && gameData.CanPickUpHeart && canTakeHeart)
        {
            ChanceDropHeart = false;
            HeartManager.Hearts[^1].CountHeart++;
            HeartManager.FillHearts(gameData.HeroUpdate);
            gameData.PickUpHeart = true;
        }

        if (gameData.PickUpHeart)
            gameData.HeroUpdate.Healths++;
        
        if (!gameData.HeroUpdate.Bounds.Intersects(Bounds) || !canTakeHeart) return;
        var directionToHero = Vector2.Normalize(Position - gameData.HeroUpdate.Position);
        var repelVector = directionToHero * 5f;
        var newPosition = Position + repelVector;
        if (Globals.InBounds(newPosition, gameData))
            Position = newPosition;

        Bounds = new Rectangle((int)Position.X, (int)Position.Y, TextureWidth,
            TextureHeight);
    }

    public void CheckChance()
    {
        var nextChance = chance.Next(0, 99);
        
        if (nextChance < 15 && !ChanceDropHeart)
        {
            ChanceDropHeart = true;
            dropHeart = true;
        }
        
        if (nextChance < 45 && nextChance > 14 && !ChanceDropHeart)
        {
            ChanceDropHeart = true;
            dropHalfHeart = true;
        }
    }
}