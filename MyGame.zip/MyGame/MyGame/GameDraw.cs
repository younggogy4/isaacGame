﻿namespace MyGame;

public class GameDraw
{
    public void Draw(GameData gameData)
    {
        HeartManager.Draw();
        EnemyManager.Draw();
        TearsManager.Draw();
        gameData.DrawHero.Draw(gameData.HeroUpdate);
        gameData.BackGround.Draw(gameData);
        if (EnemyManager.Enemies.Count<=0) gameData.DropHeartDraw.Draw(gameData.DropHeartUpdate);
    }
}