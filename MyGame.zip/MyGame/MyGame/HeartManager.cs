﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame;

public class HeartManager
{
    private static Texture2D fullHeart;
    private static Texture2D halfHeart;
    private static Texture2D emptyHeart;
    public static List<Heart> Hearts;

    public static void Init()
    {
        fullHeart = Globals.Content.Load<Texture2D>("heart");
        halfHeart = Globals.Content.Load<Texture2D>("halfHeart");
        emptyHeart = Globals.Content.Load<Texture2D>("emptyHeart");
        Hearts = new List<Heart>();
    }
    
    public static void FillHearts(HeroUpdate updateHero)
    {
        for (var i = 0; i < updateHero.Healths / 3; i++)
            Add(new Vector2(200 + 75 * i, 80));

        if (updateHero.Healths % 3 == 1)
        {
            Add(new Vector2(Hearts[^1].Position.X + 75, 80));
            Hearts[^1].CountHeart-=2;
        }

        if (updateHero.Healths % 3 == 2)
        {
            Add(new Vector2(Hearts[^1].Position.X + 75, 80));
            Hearts[^1].CountHeart--;
        }
        
    }
    

    public static void Add(Vector2 position)
    {
        Hearts.Add(new Heart(fullHeart, halfHeart, emptyHeart, position));
    }

    public static void Draw()
    {
        foreach (var heart in Hearts)
            heart.Draw();
    }
}