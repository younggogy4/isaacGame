﻿using Microsoft.Xna.Framework;

namespace MyGame;

public class EnemyData
{
    public Vector2 Position { get; set; }
    public int Speed { get; set; }
}