﻿namespace MyGame;

public class HeroAnimaton
{
    
}