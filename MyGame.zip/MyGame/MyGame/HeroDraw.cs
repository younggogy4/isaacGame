﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame;

public class HeroDraw
{
    public static Texture2D Texture { get;} = Globals.Content.Load<Texture2D>("isaac");
    
    public void Draw(HeroUpdate update)
    {
        if (update.Healths>0) Globals.SpriteBatch.Draw(Texture, update.Position, Color.White);
    }
}