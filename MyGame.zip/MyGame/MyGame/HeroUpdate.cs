﻿using Microsoft.Xna.Framework;
using MonoGame.Extended;

namespace MyGame;

public class HeroUpdate
{
    public Rectangle Bounds { get; set; }
    private int TextureWidth { get; }
    private int TextureHeight { get; }
    public int Healths;
    public Vector2 Position;
    public int Speed;
    private Timer timer = new ();
    private bool tacheble = true;
    
    public HeroUpdate(int width, int height)
    {
        Position = new Vector2(width/2, height/2);
        TextureWidth = HeroDraw.Texture.Width / 2;
        TextureHeight = HeroDraw.Texture.Height / 2;
        Bounds = (Rectangle)new EllipseF(new Point2(Position.X, Position.Y), TextureWidth, TextureHeight).BoundingRectangle;
        Speed = 300;
        Healths = 9;
    }

    public void Update(GameData gameData)
    {
        if (Healths <= 0 || HeartManager.Hearts.Count<=0) return;
        var movement = Vector2.Zero;

        if (InputManager.Direction != Vector2.Zero)
            movement = Vector2.Normalize(InputManager.Direction) * Speed * (float)Globals.Time.TotalSeconds;

        var newPosition = Position + movement;

        if (Globals.InBounds(newPosition, gameData))
            Position = newPosition;
        
        timer.Update();

        foreach (var enemy in EnemyManager.Enemies)
        {
            if (!enemy.Bounds.Intersects(Bounds)) continue;
            var directionToEnemy = Vector2.Normalize(Position - enemy.Position);
            var repelVector = directionToEnemy * 100f;
            var probablyPos = repelVector * 3f * (float)Globals.Time.TotalSeconds;
            if (Globals.InBounds(Position + probablyPos, gameData))
               Position += probablyPos;
            if (tacheble)
            {
                Healths--;
                HeartManager.Hearts[^1].CountHeart--;
                if (HeartManager.Hearts[^1].CountHeart<=0) HeartManager.Hearts.RemoveAt(HeartManager.Hearts.Count-1);
                tacheble = false;
                timer.Reset();
            }

            if (!(timer.GetTime > 1)) continue;
            tacheble = true;
            timer.Reset();
        }

        Bounds = (Rectangle)new EllipseF(Position, TextureWidth, TextureHeight).BoundingRectangle;
    }
}