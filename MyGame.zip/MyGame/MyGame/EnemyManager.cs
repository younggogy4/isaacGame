﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended;

namespace MyGame;

public class EnemyManager
{
    private static Texture2D texture;
    private int limitSpawn;
    public static List<Enemy> Enemies { get; }= new();

    public static void Init()
    {
        texture = Globals.Content.Load<Texture2D>("enemy");
    }
    public static void Add(EnemyData data)
    {
        Enemies.Add(new Enemy(texture, data));
    }
    
    public static void Draw()
    {
        foreach (var enemy in Enemies)
        {
            Globals.SpriteBatch.Draw(enemy.Texture, enemy.Position, Color.White);
        }
    }
    
    private static void SpawnEnemy(int width, int height, Random random, EnemyData enemyData, HeroUpdate updateHero)
    {
        var listZonesSpawn = new List<Rectangle>
        {
            new (95, 40, 300, 300),
            new (95, height - 180, 300, 180),
            new (width-160-300, 40, 300, 300),
            new (width-160-300, height-180-300, 300, 300)
        };

        foreach (var randomPosition in listZonesSpawn.Select(t => new Vector2(random.Next(t.Left, t.Right),
                     random.Next(t.Top, t.Bottom))))
        {
            enemyData.Speed = updateHero.Speed - 100;
            enemyData.Position = randomPosition;
            Add(enemyData);
        }
    }

    public static void Update(GameData gameData)
    {
        if (gameData.LimitSpawnEnemy < 1)
        {
            gameData.LimitSpawnEnemy++;
            SpawnEnemy(gameData.Width, gameData.Height, gameData.Random, gameData.EnemyData, gameData.HeroUpdate);
        }

        for (var i = 0; i < Enemies.Count; i++)
        {
            Enemies.Where(enemy => enemy.Bounds.Intersects(Enemies[i].Bounds)).Select(enemy =>
            {
                var directionFromEnemy = Vector2.Normalize(enemy.Position - Enemies[i].Position);
                var repelVector = -directionFromEnemy * 3f;
                var newPosition = Enemies[i].Position + repelVector;
                if (Globals.InBounds(newPosition, gameData)) Enemies[i].Position = newPosition;
                return enemy;
            }).ToList();

            var directionToHero = Vector2.Normalize(gameData.HeroUpdate.Position - Enemies[i].Position);

            if (gameData.HeroUpdate.Bounds.Intersects(Enemies[i].Bounds) && gameData.HeroUpdate.Healths > 0)
            {
                var enemyRepelDistance = 1f;
                var repelVector = -directionToHero * enemyRepelDistance;
                var newPosition = Enemies[i].Position + repelVector;
                if (Globals.InBounds(newPosition, gameData)) Enemies[i].Position = newPosition;
            }
            else if (gameData.HeroUpdate.Healths > 0)
                Enemies[i].Position +=
                    directionToHero * gameData.EnemyData.Speed * (float)Globals.Time.TotalSeconds;

            Enemies[i].Bounds = (Rectangle)new EllipseF(Enemies[i].Position,
                Enemies[i].TextureWidth, Enemies[i].TextureHeight).BoundingRectangle;
            if (TearsManager.Tears.Any(tear => Enemies[i].Bounds.Contains(tear.Position)))
                Enemies[i].Helths--;

            if (Enemies[i].Helths > 0) continue;
            Enemies.RemoveAt(i);
            i--;
        }
    }
}