﻿namespace MyGame;

public class AnimationManager
{
    
}