﻿using Microsoft.Xna.Framework;

namespace MyGame;

public class DropHeartDraw
{
    private Timer timer = new();
    
    public void Draw(DropHeartUpdate dropHeartUpdate)
    {
        if (DropHeartUpdate.CountCheckChance < 1)
        {
            DropHeartUpdate.CountCheckChance++;
            dropHeartUpdate.CheckChance();
        }

        if (!DropHeartUpdate.ChanceDropHeart) return;
        timer.Update();
        if (timer.GetTime>0.6)
        {
            DropHeartUpdate.canTakeHeart = true;
            if (dropHeartUpdate.dropHeart) Globals.SpriteBatch.Draw(dropHeartUpdate.textureHeart,
                new Rectangle((int)DropHeartUpdate.Position.X, (int)DropHeartUpdate.Position.Y, DropHeartUpdate.TextureWidth, DropHeartUpdate.TextureHeight),
                new Rectangle(0, 0, dropHeartUpdate.textureHeart.Width, dropHeartUpdate.textureHeart.Height),
                Color.White);
            if (dropHeartUpdate.dropHalfHeart) Globals.SpriteBatch.Draw(dropHeartUpdate.textureHalfHeart,
                new Rectangle((int)DropHeartUpdate.Position.X, (int)DropHeartUpdate.Position.Y, DropHeartUpdate.TextureWidth, DropHeartUpdate.TextureHeight),
                new Rectangle(0, 0, dropHeartUpdate.textureHalfHeart.Width, dropHeartUpdate.textureHalfHeart.Height),
                Color.White);
        }
    }
}